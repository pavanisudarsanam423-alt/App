function MyAppointments() {
  return (
    <div>
      <h2>My Appointments</h2>
      <p>No appointments yet</p>
    </div>
  );
}

export default MyAppointments;
