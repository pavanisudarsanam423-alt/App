import "../styles/Auth.css";

function Register() {
  return (
    <div className="auth">
      <h2>Register</h2>
      <input placeholder="Name" />
      <input placeholder="Email" />
      <input type="password" placeholder="Password" />
      <button>Register</button>
    </div>
  );
}

export default Register;
