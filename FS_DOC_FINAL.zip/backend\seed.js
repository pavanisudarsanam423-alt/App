const mongoose = require("mongoose");
const dotenv = require("dotenv");
const Doctor = require("./models/doctor");
const Patient = require("./models/patient");

const Appointment = require("./models/appointment");

dotenv.config();

const seedDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("Connected to MongoDB for seeding...");

        // Clear existing data
        await Doctor.deleteMany();
        await Patient.deleteMany();
        await Appointment.deleteMany();

        // Create Test Doctor
        const doctor = await Doctor.create({
            name: "Dr. Rajesh Kumar",
            email: "dr@hospital.com",
            password: "pass",
            specialization: "Cardiology",
            qualification: "MBBS, MD",
            location: "Hyderabad",
            available: true
        });

        // Create Test Patient
        const patient = await Patient.create({
            name: "Ayesha Khan",
            email: "pat@hospital.com",
            password: "pass"
        });

        // Create Test Appointment
        await Appointment.create({
            doctorId: doctor._id,
            doctorName: doctor.name,
            patientName: patient.name,
            patientEmail: patient.email,
            date: "2026-03-05",
            time: "10:30 AM",
            status: "Scheduled"
        });

        console.log("Database seeded successfully!");
        console.log("-----------------------------------------");
        console.log("Test Credentials:");
        console.log("DOCTOR  | Email: dr@hospital.com  | Pass: pass");
        console.log("PATIENT | Email: pat@hospital.com | Pass: pass");
        console.log("ADMIN   | Email: admin            | Pass: admin");
        console.log("-----------------------------------------");

        process.exit(0);
    } catch (error) {
        console.error("Error seeding DB:", error);
        process.exit(1);
    }
};

seedDB();
