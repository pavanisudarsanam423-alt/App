export const doctors = [
  {
    id: 1,
    name: "Dr. Sharma",
    specialist: "Cardiologist",
    location: "Hyderabad",
    available: true,
    slots: ["10:00 AM", "11:00 AM", "2:00 PM"]
  },
  {
    id: 2,
    name: "Dr. Khan",
    specialist: "Dermatologist",
    location: "Bangalore",
    available: false,
    slots: []
  }
];
