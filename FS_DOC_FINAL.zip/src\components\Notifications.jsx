function Notifications({ message }) {
  return (
    <div style={{ background: "#e3f2fd", padding: "10px", margin: "10px 0" }}>
      {message}
    </div>
  );
}

export default Notifications;
