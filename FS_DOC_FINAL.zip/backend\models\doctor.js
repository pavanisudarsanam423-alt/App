const mongoose = require("mongoose");

const doctorSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  specialization: String,
  qualification: String,
  location: String,
  available: Boolean
});

module.exports = mongoose.model("Doctor", doctorSchema);