import { useState, useEffect } from "react";
import { logoutUser } from "../utils/auth";
import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

function PatientDashboard() {
  const { dark, setDark } = useContext(ThemeContext);
  const navigate = useNavigate();

  const [appointments, setAppointments] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [doctors, setDoctors] = useState([]);

  useEffect(() => {
    fetch("/api/doctors")
      .then((res) => res.json())
      .then((data) => setDoctors(data));
  }, []);

  const bookAppointment = async () => {
    if (!selectedDoctor || !date || !time) {
      alert("Please fill all fields");
      return;
    }

    const doctorNode = doctors.find((d) => d.name === selectedDoctor);
    if (!doctorNode) return;

    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          doctorId: doctorNode._id,
          patientName: JSON.parse(localStorage.getItem("user")).name,
          date,
          time,
        }),
      });
      const newAppt = await res.json();
      setAppointments([...appointments, { ...newAppt, doctor: selectedDoctor }]);
      setSelectedDoctor("");
      setDate("");
      setTime("");
    } catch (err) {
      alert("Failed to book");
    }
  };

  return (
    <div style={styles.container}>
      <button
        style={styles.logout}
        onClick={() => {
          logoutUser();
          navigate("/");
        }}
      >
        Logout
      </button>

      <h2 style={styles.heading}>Patient Dashboard</h2>

      {/* Book Appointment */}
      <div style={styles.card}>
        <h3>Book Appointment</h3>

        <select
          style={styles.select}
          value={selectedDoctor}
          onChange={(e) => setSelectedDoctor(e.target.value)}
        >
          <option value="">Select Doctor</option>
          {doctors.map((doc, index) => (
            <option key={index} value={doc.name}>
              {doc.name} - {doc.specialization} ({doc.location})
            </option>
          ))}
        </select>

        <input
          type="date"
          style={styles.input}
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />

        <input
          type="time"
          style={styles.input}
          value={time}
          onChange={(e) => setTime(e.target.value)}
        />

        <button style={styles.bookBtn} onClick={bookAppointment}>
          Book Appointment
        </button>
      </div>

      {/* My Appointments */}
      <h3>My Appointments</h3>

      {appointments.length === 0 && <p>No appointments yet</p>}

      {appointments.map((appt, index) => (
        <div key={index} style={styles.card}>
          <p><strong>Doctor:</strong> {appt.doctor}</p>
          <p><strong>Date:</strong> {appt.date}</p>
          <p><strong>Time:</strong> {appt.time}</p>
          <p><strong>Status:</strong> {appt.status}</p>
        </div>
      ))}
    </div>
  );
}

const styles = {
  container: {
    padding: "30px 50px",
    background: "linear-gradient(135deg, #ecfeff, #f0fdfa)",
    minHeight: "100vh",
    fontFamily: "Segoe UI, sans-serif",
  },
  heading: {
    color: "#0f766e",
    fontSize: "28px",
    fontWeight: 700,
    marginBottom: 25,
  },
  card: {
    background: "#ffffff",
    padding: "22px 26px",
    borderRadius: 18,
    marginBottom: 18,
    boxShadow: "0 15px 35px rgba(15,118,110,0.15)",
    transition: "all 0.3s ease",
  },
  select: {
    width: "100%",
    padding: "12px 14px",
    borderRadius: 10,
    border: "1px solid #cbd5e1",
    marginBottom: 15,
    fontSize: 14,
    backgroundColor: "#f8fafc",
  },
  input: {
    width: "100%",
    padding: "12px 14px",
    borderRadius: 10,
    border: "1px solid #cbd5e1",
    marginBottom: 15,
    fontSize: 14,
  },
  bookBtn: {
    background: "linear-gradient(135deg, #0f766e, #0d9488)",
    color: "#fff",
    padding: "12px 24px",
    borderRadius: 14,
    border: "none",
    fontSize: 15,
    fontWeight: 600,
    cursor: "pointer",
    boxShadow: "0 10px 25px rgba(15,118,110,0.4)",
    transition: "all 0.25s ease",
  },
  logout: {
    float: "right",
    background: "linear-gradient(135deg, #0f766e, #115e59)",
    color: "#fff",
    padding: "8px 18px",
    borderRadius: 12,
    border: "none",
    fontWeight: 600,
    cursor: "pointer",
    boxShadow: "0 6px 16px rgba(15,118,110,0.4)",
  },
};

export default PatientDashboard;
