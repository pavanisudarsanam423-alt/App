import "../styles/Home.css";

function Home() {
  return (
    <div className="home">
      <h1>Book Doctor Appointments Easily</h1>
      <p>Fast • Simple • Reliable</p>
      <button>Book Appointment</button>
    </div>
  );
}

export default Home;
