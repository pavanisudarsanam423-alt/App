import "../styles/Navbar.css";

function Navbar() {
  return (
    <nav className="navbar">
      <h2>DocBook</h2>
      <ul>
        <li>Home</li>
        <li>Login</li>
        <li>Register</li>
      </ul>
    </nav>
  );
}

export default Navbar;
