import "../styles/Dashboard.css";

function Dashboard() {
  return (
    <div className="dash">
      <h2>Patient Dashboard</h2>
      <p>Welcome to your dashboard</p>
    </div>
  );
}

export default Dashboard;
