import { useState, useEffect } from "react";
import { logoutUser } from "../utils/auth";
import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

function AdminDashboard() {
  const { dark, setDark } = useContext(ThemeContext);
  const navigate = useNavigate();

  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]); // if had api for patients
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    fetch("/api/doctors")
      .then((res) => res.json())
      .then((data) => setDoctors(data));

    fetch("/api/appointments")
      .then((res) => res.json())
      .then((data) => setAppointments(data));

    fetch("/api/patients")
      .then((res) => res.json())
      .then((data) => setPatients(data));
  }, []);

  const toggleDoctorStatus = (id) => {
    // normally an API call
    setDoctors(
      doctors.map((doc) =>
        doc._id === id
          ? {
            ...doc,
            available: !doc.available,
          }
          : doc
      )
    );
  };

  const cancelAppointment = async (id) => {
    try {
      const res = await fetch(`/api/appointments/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "Cancelled by Admin" }),
      });
      const updatedAppt = await res.json();
      setAppointments(
        appointments.map((a) =>
          a._id === id ? updatedAppt : a
        )
      );
    } catch (err) {
      alert("Error canceling");
    }
  };

  return (
    <div style={styles.container}>
      <button
        style={styles.logout}
        onClick={() => {
          logoutUser();
          navigate("/");
        }}
      >
        Logout
      </button>

      <h2 style={styles.heading}>Admin Dashboard</h2>

      {/* Doctors */}
      <div style={styles.card}>
        <h3>Doctors</h3>
        {doctors.map((doc) => (
          <div key={doc._id} style={styles.row}>
            <span>
              {doc.name} — <strong>{doc.available ? "Active" : "Blocked"}</strong>
            </span>
            <button onClick={() => toggleDoctorStatus(doc._id)}>
              {doc.available ? "Block" : "Unblock"}
            </button>
          </div>
        ))}
      </div>

      {/* Patients */}
      <div style={styles.card}>
        <h3>Patients</h3>
        {patients.length > 0 ? patients.map((p) => (
          <div key={p._id} style={styles.row}>
            <span>{p.name} — {p.email}</span>
          </div>
        )) : <p>No patients registered yet.</p>}
      </div>

      {/* Appointments */}
      <div style={styles.card}>
        <h3>Appointments</h3>
        {appointments.length > 0 ? appointments.map((a) => (
          <div key={a._id} style={styles.row}>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <span><strong>Dr. {a.doctorName}</strong> with <strong>{a.patientName}</strong></span>
              <small style={{ color: "#666" }}>{a.date} at {a.time} — <span style={getStatusStyle(a.status)}>{a.status}</span></small>
            </div>
            {a.status !== "Cancelled by Admin" && (
              <button onClick={() => cancelAppointment(a._id)}>
                Cancel
              </button>
            )}
          </div>
        )) : <p>No appointments found.</p>}
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: 30,
    background: "#f0fdfa",
    minHeight: "100vh",
  },
  heading: {
    color: "#0f766e",
  },
  card: {
    background: "#fff",
    padding: 20,
    borderRadius: 14,
    marginBottom: 15,
    boxShadow: "0 8px 20px rgba(0,0,0,0.08)",
  },
  row: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  logout: {
    float: "right",
    background: "#0f766e",
    color: "#fff",
  },
};

const getStatusStyle = (status) => {
  if (status === "Scheduled") return { color: "#059669", fontWeight: "bold" };
  if (status.includes("Cancelled")) return { color: "#dc2626", fontWeight: "bold" };
  return { color: "#d97706", fontWeight: "bold" };
};

export default AdminDashboard;
