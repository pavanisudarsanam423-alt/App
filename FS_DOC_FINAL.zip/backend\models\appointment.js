const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema({
  doctorId: mongoose.Schema.Types.ObjectId,
  doctorName: String,
  patientName: String,
  patientEmail: String,
  date: String,
  time: String,
  status: {
    type: String,
    default: "Pending"
  }
});

module.exports = mongoose.model("Appointment", appointmentSchema);