const Doctor = require("../models/doctor");
const Patient = require("../models/patient");

exports.login = async (req, res) => {
  const { role, email, password } = req.body;

  if (role === "admin" && email === "admin" && password === "admin") {
    return res.json({ success: true, role, message: "Welcome Admin" });
  }

  let user = null;
  if (role === "doctor") user = await Doctor.findOne({ email, password });
  if (role === "patient") user = await Patient.findOne({ email, password });

  if (!user) {
    return res.status(401).json({ success: false, message: "Invalid credentials" });
  }

  res.json({ success: true, role, user, message: "Login successful" });
};