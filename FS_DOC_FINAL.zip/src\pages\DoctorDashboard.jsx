import { useState, useEffect } from "react";
import { logoutUser } from "../utils/auth";
import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

function DoctorDashboard() {
  const { dark, setDark } = useContext(ThemeContext);
  const navigate = useNavigate();

  const [onLeave, setOnLeave] = useState(false);
  const [appointments, setAppointments] = useState([]);
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    if (user && user._id) {
      fetch(`/api/appointments/doctor/${user._id}`)
        .then((res) => res.json())
        .then((data) => setAppointments(data))
        .catch(err => console.error("Fetch error:", err));
    }
  }, [user]);

  const [slots, setSlots] = useState([
    { time: "10:00 - 11:00", available: true },
    { time: "11:00 - 12:00", available: true },
    { time: "12:00 - 01:00", available: false },
  ]);

  const updateStatus = async (id, status) => {
    try {
      const res = await fetch(`/api/appointments/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const updated = await res.json();
      setAppointments((prev) =>
        prev.map((appt) => (appt._id === updated._id ? updated : appt))
      );
    } catch (err) {
      alert("Error updating status");
    }
  };

  const applyLeave = () => {
    setOnLeave(true);
    alert("Leave applied. Patients notified.");
  };

  return (
    <div style={styles.container}>
      <button
        style={styles.logout}
        onClick={() => {
          logoutUser();
          navigate("/");
        }}
      >
        Logout
      </button>

      <h2 style={styles.heading}>Doctor Dashboard</h2>

      {/* Profile */}
      <div style={styles.card}>
        <h3>{user?.name || "Dr. Rajesh Kumar"}</h3>
        <p>{user?.qualification || "MBBS, MD (Cardiology)"}</p>
        <p>Email: {user?.email || "rajesh@hospital.com"}</p>
        <p>Location: {user?.location || "Hyderabad"}</p>

        <button style={styles.leaveBtn} onClick={applyLeave}>
          Apply Leave (2 days notice)
        </button>

        {onLeave && (
          <p style={styles.leaveText}>
            You are on leave. New bookings blocked.
          </p>
        )}
      </div>

      <h3>Availability</h3>

      {slots.map((slot, i) => (
        <div key={i} style={styles.card}>
          <div style={styles.slotRow}>
            <span style={{ fontWeight: 600 }}>{slot.time}</span>

            <button
              style={{
                ...styles.availabilityBtn,
                ...(slot.available ? styles.available : styles.unavailable),
              }}
              onClick={() =>
                setSlots(
                  slots.map((s, idx) =>
                    idx === i ? { ...s, available: !s.available } : s
                  )
                )
              }
            >
              {slot.available ? "Mark Unavailable" : "Mark Available"}
            </button>
          </div>
        </div>
      ))}


      {/* Appointments */}
      <h3>Appointments</h3>
      {appointments.length === 0 && <p>No appointments yet.</p>}
      {appointments.map((appt) => (
        <div key={appt._id} style={styles.card}>
          <p><strong>Patient:</strong> {appt.patientName} (<small>{appt.patientEmail}</small>)</p>
          <p><strong>Date:</strong> {appt.date}</p>
          <p><strong>Time:</strong> {appt.time}</p>
          <p>
            <strong>Status:</strong>{" "}
            <span style={statusColor(appt.status)}>
              {appt.status}
            </span>
          </p>

          {!onLeave && appt.status === "Pending" && (
            <>
              <button
                style={styles.accept}
                onClick={() => updateStatus(appt._id, "Accepted")}
              >
                Accept
              </button>
              <button
                style={styles.reject}
                onClick={() => updateStatus(appt._id, "Rejected")}
              >
                Reject
              </button>
            </>
          )}
        </div>
      ))}
    </div>
  );
}

const statusColor = (status) => ({
  color:
    status === "Accepted"
      ? "#15803d"
      : status === "Rejected"
        ? "#b91c1c"
        : "#854d0e",
});

const styles = {
  container: {
    padding: "30px 50px",
    background: "linear-gradient(135deg, #ecfeff, #f0fdfa)",
    minHeight: "100vh",
    fontFamily: "Segoe UI, sans-serif",
  },

  heading: {
    color: "#0f766e",
    fontSize: "28px",
    fontWeight: "700",
    marginBottom: 20,
  },

  card: {
    background: "#ffffff",
    padding: "22px 26px",
    borderRadius: "18px",
    marginBottom: 18,
    boxShadow: "0 15px 35px rgba(15,118,110,0.15)",
    transition: "transform 0.3s ease, box-shadow 0.3s ease",
  },

  cardHover: {
    transform: "translateY(-4px)",
    boxShadow: "0 20px 45px rgba(15,118,110,0.25)",
  },

  accept: {
    background: "linear-gradient(135deg, #22c55e, #16a34a)",
    color: "#fff",
    padding: "10px 18px",
    borderRadius: 10,
    border: "none",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
    marginRight: 10,
    boxShadow: "0 6px 16px rgba(34,197,94,0.4)",
    transition: "all 0.25s ease",
  },

  reject: {
    background: "linear-gradient(135deg, #ef4444, #dc2626)",
    color: "#fff",
    padding: "10px 18px",
    borderRadius: 10,
    border: "none",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
    boxShadow: "0 6px 16px rgba(239,68,68,0.4)",
    transition: "all 0.25s ease",
  },

  leaveBtn: {
    background: "linear-gradient(135deg, #0f766e, #0d9488)",
    color: "#fff",
    padding: "10px 20px",
    borderRadius: 12,
    border: "none",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
    marginTop: 12,
    boxShadow: "0 8px 20px rgba(15,118,110,0.4)",
    transition: "all 0.25s ease",
  },

  leaveText: {
    marginTop: 12,
    color: "#b91c1c",
    fontWeight: "600",
    background: "#fee2e2",
    padding: 10,
    borderRadius: 10,
  },
  availabilityBtn: {
    padding: "8px 16px",
    borderRadius: 10,
    border: "none",
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer",
    marginLeft: 15,
    transition: "all 0.25s ease",
  },

  available: {
    background: "linear-gradient(135deg, #22c55e, #16a34a)",
    color: "#fff",
    boxShadow: "0 6px 16px rgba(34,197,94,0.45)",
  },

  unavailable: {
    background: "linear-gradient(135deg, #f97316, #ea580c)",
    color: "#fff",
    boxShadow: "0 6px 16px rgba(249,115,22,0.45)",
  },

  slotRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },


  logout: {
    float: "right",
    background: "linear-gradient(135deg, #0f766e, #115e59)",
    color: "#fff",
    padding: "8px 16px",
    borderRadius: 10,
    border: "none",
    fontWeight: 600,
    cursor: "pointer",
    boxShadow: "0 6px 16px rgba(15,118,110,0.4)",
  },
};


export default DoctorDashboard;
