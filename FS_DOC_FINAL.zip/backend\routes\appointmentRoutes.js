const express = require("express");
const router = express.Router();
const Appointment = require("../models/appointment");

// Book appointment
router.post("/", async (req, res) => {
    try {
        const { doctorId, patientName, date, time } = req.body;
        const newAppt = await Appointment.create({ doctorId, patientName, date, time });
        res.json(newAppt);
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// Get appointments for a doctor
router.get("/doctor/:doctorId", async (req, res) => {
    const appointments = await Appointment.find({ doctorId: req.params.doctorId });
    res.json(appointments);
});

// Get all appointments (Admin)
router.get("/", async (req, res) => {
    const appointments = await Appointment.find({});
    res.json(appointments);
});

// Update appointment status (Doctor)
router.put("/:id/status", async (req, res) => {
    const { status } = req.body;
    const appt = await Appointment.findByIdAndUpdate(req.params.id, { status }, { new: true });
    res.json(appt);
});

module.exports = router;
