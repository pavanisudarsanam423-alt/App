function BookAppointment() {
  return (
    <div>
      <h2>Book Appointment</h2>
      <p>Select doctor and time slot</p>
    </div>
  );
}

export default BookAppointment;
